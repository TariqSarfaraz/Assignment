
import java.util.*;

public class RepeatingDecimal 
{
	
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		int numerator, denominator;
		
		System.out.print("Enter Numberator : ");
		numerator = scan.nextInt();
		
		System.out.print("Enter Denominator : ");
		denominator = scan.nextInt();
		
		String result = fractionToDecimal(numerator, denominator);
		
		if (result == "")
			System.out.print("There is no repeating decimal.");
		else
			System.out.print("Here " + result + " is repeating decimal.");
	}

	static String fractionToDecimal(int a, int b)
	{
		String result = "";

		HashMap<Integer, Integer> hm = new HashMap<>();
		hm.clear();

		int remainder = a % b;

		while ((remainder != 0) && (!hm.containsKey(remainder))) 
		{
			hm.put(remainder, result.length());

			remainder = remainder * 10;

			int res_part = remainder / b;
			result += String.valueOf(res_part);

			remainder = remainder % b;
		}

		if (remainder == 0)
			return "";
		else if (hm.containsKey(remainder))
			return result.substring(hm.get(remainder));

		return "";
	}

}
