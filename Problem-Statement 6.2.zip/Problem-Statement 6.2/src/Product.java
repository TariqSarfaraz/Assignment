import java.util.Hashtable;
import java.util.Scanner;

public class Product {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		Hashtable<String, String> ht = new Hashtable<String, String>();

		System.out.println("Enter the product ID and NAME:");
		for (int i = 0; i < 3; i++) {
			ht.put(scan.next(), scan.next());
		}

		System.out.println("Enter the product Id to be searched:");
		String pid = scan.next();
		if (ht.containsKey(pid))
		{
			System.out.println(ht.get(pid));
		}
		else 
		{
			System.out.println("Do not exist");
		}

		System.out.println("Enter the product ID to be removed:");
		String id = scan.next();
		ht.remove(id);
		System.out.println("Item removed");
		System.out.println("The product list is:");
		System.out.println(ht.toString());

	}
}