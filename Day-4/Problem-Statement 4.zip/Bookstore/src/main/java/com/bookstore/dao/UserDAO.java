package com.bookstore.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.bookstore.dbutil.DBUtil;
import com.bookstore.domain.User;

public class UserDAO {

	Connection con = DBUtil.getConnection();
	PreparedStatement ps;
	ResultSet rs;
	
	public boolean getUser(User user) throws SQLException
	{
		boolean status = false;
		ps = con.prepareStatement("select first_name from users where user_name = ? and password = ?");
		ps.setString(1, user.getUserName());
		ps.setString(2, user.getPassword());
		rs = ps.executeQuery();
		status = rs.next();
		
		return status;
	}
	
	public int addUser(User user) throws SQLException
	{
		ps = con.prepareStatement("insert into users values (?, ?, ?, ?, ?, ?)");
		ps.setString(1, user.getFullName());
		ps.setString(2, user.getAddress());
		ps.setString(3, user.getEmail());
		ps.setString(4, user.getUserName());
		ps.setString(5, user.getPassword());
		ps.setString(6, java.time.LocalDate.now().toString());
		return ps.executeUpdate();
	}
	
	public ResultSet getBooks() throws SQLException
	{
		ps = con.prepareStatement("select * from books");
		rs = ps.executeQuery();
		return rs;
	}
}
