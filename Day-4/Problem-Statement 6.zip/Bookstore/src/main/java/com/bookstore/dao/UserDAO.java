package com.bookstore.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.bookstore.dbutil.DBUtil;
import com.bookstore.domain.User;

public class UserDAO {

	Connection con = DBUtil.getConnection();
	PreparedStatement ps;
	ResultSet rs;
	
	public boolean userLogin(User user) throws SQLException
	{
		boolean status = false;
		ps = con.prepareStatement("select first_name from users where user_name = ? and password = ?");
		ps.setString(1, user.getUserName());
		ps.setString(2, user.getPassword());
		rs = ps.executeQuery();
		status = rs.next();
		
		return status;
	}
	
	public int userRegister(User user) throws SQLException
	{
		ps = con.prepareStatement("insert into users values (?, ?, ?, ?, ?, ?)");
		ps.setString(1, user.getFullName());
		ps.setString(2, user.getAddress());
		ps.setString(3, user.getEmail());
		ps.setString(4, user.getUserName());
		ps.setString(5, user.getPassword());
		ps.setString(6, java.time.LocalDate.now().toString());
		return ps.executeUpdate();
	}
	
	public ResultSet getBooks() throws SQLException
	{
		ps = con.prepareStatement("select * from books");
		rs = ps.executeQuery();
		return rs;
	}
	
	public boolean resetPasswordValidation(User user) throws SQLException
	{
		boolean status = false;
		ps = con.prepareStatement("select first_name from users where user_name = ? and email = ?");
		ps.setString(1, user.getUserName());
		ps.setString(2, user.getEmail());
		rs = ps.executeQuery();
		status = rs.next();
		
		return status;
	}
	
	public int updatePassword(User user) throws SQLException
	{
		ps = con.prepareStatement("update users set password = ? where email = ? ");
		ps.setString(1, user.getPassword());
		ps.setString(2, user.getEmail());
		return ps.executeUpdate();
	}
	
	public ResultSet bookById(int id) throws SQLException
	{
		ps = con.prepareStatement("select * from books where book_id = ? ");
		ps.setInt(1, id);
		return ps.executeQuery();
	}
}










