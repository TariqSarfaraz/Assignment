package com.bookstore.domain;

public class User {

	String userName;
	String password;
	String fullName;
	String address;
	String email;
	String regdate;

	public User() {

	}

	public User(String userName, String password, String fullName, String address, String email, String regdate) {
		super();
		this.userName = userName;
		this.password = password;
		this.fullName = fullName;
		this.address = address;
		this.email = email;
		this.regdate = regdate;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

}
