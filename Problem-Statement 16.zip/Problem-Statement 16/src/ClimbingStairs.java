import java.util.Scanner;

public class ClimbingStairs 
{
	public static void main(String args[]) 
	{
		int input;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the number: ");
		input = scan.nextInt();
		
		System.out.println("Number of ways = " + ways(input));
	}

	static int ways(int input) 
	{
		return fib(input + 1);
	}
	
	static int fib(int n) 
	{
		if (n <= 1)
			return n;
		return fib(n - 1) + fib(n - 2);
	}
	
}
