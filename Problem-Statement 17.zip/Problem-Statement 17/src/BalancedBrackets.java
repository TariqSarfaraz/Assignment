import java.util.*;

public class BalancedBrackets 
{
	public static void main(String[] args) 
	{
		String exp = "[()]{}{[()()]()}";

		if (check(exp))
			System.out.println("Balanced ");
		else
			System.out.println("Not Balanced ");
	}

	static boolean check(String exp) 
	{
		Deque<Character> balance = new ArrayDeque<Character>();

		for (int i = 0; i < exp.length(); i++) 
		{
			char x = exp.charAt(i);

			if (x == '(' || x == '[' || x == '{')
			{
				balance.push(x);
				continue;
			}

			if (balance.isEmpty())
				return false;
			char check;
			
			switch (x) 
			{
			case ')':
				check = balance.pop();
				if (check == '{' || check == '[')
					return false;
				break;

			case '}':
				check = balance.pop();
				if (check == '(' || check == '[')
					return false;
				break;

			case ']':
				check = balance.pop();
				if (check == '(' || check == '{')
					return false;
				break;
			}
		}
		return (balance.isEmpty());
	}

}
