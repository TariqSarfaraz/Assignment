
public class Main {

	public static void main(String[] args) {
		Main obj = new Main();
		obj.showBooks();
	}

	public void createBooks() {
		Book book[] = new Book[2];
		book[0] = new Book("Java Programing ", 350.50);
		book[1] = new Book("Let Us C", 200.00);
		for (int i = 0; i < book.length; i++) {
			book[i].display();
			System.out.println(" ");
		}

	}

	public void showBooks() {
		createBooks();
	}
}
