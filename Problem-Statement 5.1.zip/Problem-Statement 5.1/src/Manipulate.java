
public class Manipulate {

	public static void main(String[] args) {

		String str = "JAVA is Simple";

		// To print String in Uppercase
		System.out.println(str.toUpperCase());
		
		// To print String in lowercase
		System.out.println(str.toLowerCase());
		
		// To Print First Char of each Word
		System.out.println(str.charAt(0) + " " + str.charAt(5) + " " + str.charAt(8));
		
		// To Print "Simple is JAVA"
		String[] str1 = str.split(" ");
		for (int i = str1.length - 1; i >= 0; i--)
			System.out.print(str1[i] + " ");

		System.out.println();

		// To print "AVAJ si elpmiS"
		StringBuilder s = new StringBuilder(str);
		str = s.reverse().toString();
		String[] rev = str.split(" ");
		StringBuilder reverse = new StringBuilder();
		for(int i = rev.length - 1; i >= 0; i--)
			reverse.append(rev[i]).append(" ");
		
		System.out.println(reverse.toString());
	
		// To print length of String
		System.out.println(str.length());
		
	}
}
