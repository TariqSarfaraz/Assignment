package com.mycompany.app;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.domain.Product;

public class ProductManagementApp {

	public static void main(String[] args) throws SQLException {

		String option;
		Scanner scan = new Scanner(System.in);
		ProductManagementDAO dao = new ProductManagementDAO();

		do {
			System.out.println("\nA. View Products");
			System.out.println("B. Add Product");
			System.out.println("C. Update Product");
			System.out.println("D. Delete Product");
			System.out.println("E. Search Product");
			System.out.println("F. Exit");
			System.out.println("=========================");
			System.out.println("Enter an Option");
			System.out.println("=========================");

			option = scan.next();

			switch (option.toUpperCase()) 
			{
			case "A":
				dao.viewProducts();
				break;

			case "B":
				Product addproduct = new Product();
				System.out.println("Enter Product Id : ");
				addproduct.setProductId(scan.next());
				System.out.println("Enter Product Name :");
				addproduct.setProductName(scan.next());
				System.out.println("Enter Product Price :");
				addproduct.setProductPrice(scan.nextInt());

				if (dao.addProduct(addproduct) == 1)
					System.out.println("Product added successfully.");
				else
					System.out.println("There was an error while adding.");

				break;

			case "C":
				Product updproduct = new Product();
				System.out.println("Enter Product Id : ");
				updproduct.setProductId(scan.next());
				System.out.println("Enter Product Name :");
				updproduct.setProductName(scan.next());
				System.out.println("Enter Product Price :");
				updproduct.setProductPrice(scan.nextInt());
				
				if(dao.updateProduct(updproduct) == 1)
					System.out.println("Product Updated successfully.");
				else
					System.out.println("There was an error while Updating.");
				
				break;

			case "D":
				Product delProduct = new Product();
				System.out.println("Enter Product Id :");
				delProduct.setProductId(scan.next());
				
				if(dao.deleteProduct(delProduct) == 1)
					System.out.println("Product deleted successfully.");
				else
					System.out.println("There was an error in deleting product.");
				break;

			case "E":
				Product searchProduct = new Product();
				System.out.println("Enter Product ID : ");
				searchProduct.setProductId(scan.next());
				
				dao.searchProduct(searchProduct);
				
				break;

			case "F":
				System.out.println("********************** THANK YOU ***********************");
				System.exit(1);
				break;

			default:
				System.out.println("Please Enter a Valid Option.");
				break;
			}
		} while (!option.equalsIgnoreCase("F"));
	}
}
