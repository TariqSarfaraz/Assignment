package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Product;

public class ProductManagementDAO {

	PreparedStatement ps;
	ResultSet rs;

	public void viewProducts() throws SQLException {

		Connection con = DBUtil.getCon();
		ps = con.prepareStatement("select * from product");
		rs = ps.executeQuery();

		while (rs.next()) {
			System.out.println("\nProduct Id : " + rs.getString(1));
			System.out.println("Product Name : " + rs.getString(2));
			System.out.println("Product Price : " + rs.getString(3) + "\n\n");
		}
	}

	public int addProduct(Product product) throws SQLException {

		Connection con = DBUtil.getCon();
		ps = con.prepareStatement("insert into product values (?, ?, ?)");
		ps.setString(1, product.getProductId());
		ps.setString(2, product.getProductName());
		ps.setInt(3, product.getProductPrice());
		return ps.executeUpdate();

	}

	public int updateProduct(Product product) throws SQLException {
		Connection con = DBUtil.getCon();
		ps = con.prepareStatement("update product set p_name = ?, p_price = ? where p_id = ?");
		ps.setString(1, product.getProductName());
		ps.setInt(2, product.getProductPrice());
		ps.setString(3, product.getProductId());
		return ps.executeUpdate();
	}

	public int deleteProduct(Product product) throws SQLException {

		Connection con = DBUtil.getCon();
		ps = con.prepareStatement("delete from product where p_id = ?");
		ps.setString(1, product.getProductId());
		return ps.executeUpdate();
	}

	public void searchProduct(Product product) throws SQLException {

		Connection con = DBUtil.getCon();
		ps = con.prepareStatement("select * from product where p_id = ?");
		ps.setString(1, product.getProductId());
		rs = ps.executeQuery();

		while (rs.next()) {
			System.out.println("\nProduct Id : " + rs.getString(1));
			System.out.println("Product Name : " + rs.getString(2));
			System.out.println("Product Price : " + rs.getString(3) + "\n\n");
		}
	}

}
