
create table Books (
Book_Id int primary key,
Book_Name varchar(50),
Author varchar(50),
Price int
);

create table Order_Details (
Order_Id int primary key,
Book_Id int,
Cust_Name varchar(50),
Phone_No long,
Address varchar(50),
Order_Date date,
Quantity int
);

create table Users (
first_name varchar(50),
address varchar(50),
email varchar(50) unique,
user_name varchar(50),
password varchar(50),
registration_date date
);
