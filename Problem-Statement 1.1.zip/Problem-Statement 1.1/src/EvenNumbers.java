import java.util.Scanner;

public class EvenNumbers 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		int n;
		
		System.out.println("Enter the Number:");
		n = scan.nextInt();
		
		System.out.println("\nThe even numbers less than " + n + " are: ");
		
		for(int i = 2; i <= n; i++)
		{
			if(i%2 == 0)
			{
				System.out.print(i + " ");
			}
		}
		
	}

}
