
public class TestRectangle {

	public static void main(String[] args) {
		
		Rectangle r1 = new Rectangle(2, 4);
		Rectangle r2 = new Rectangle(10, 20);
		Rectangle r3 = new Rectangle(3, 6);
		Rectangle r4 = new Rectangle(8, 12);
		Rectangle r5 = new Rectangle(20, 4);
		
		r1.area();
		r2.area();
		r3.area();
		r4.area();
		r5.area();
		
	}
}
