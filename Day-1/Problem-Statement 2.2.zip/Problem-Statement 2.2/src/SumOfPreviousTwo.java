import java.util.Scanner;

public class SumOfPreviousTwo {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int firstNum, secondNum;
		
		System.out.println("Enter Two Numbers:");
		firstNum = scan.nextInt();
		secondNum = scan.nextInt();
		
		System.out.print(firstNum + " " + secondNum);
		
		for(int i = 2; i <= 14; i++)
		{
			int thirdNum = firstNum + secondNum;
			System.out.print(" " + thirdNum);
			firstNum = secondNum;
			secondNum = thirdNum;
		}
	}
}
