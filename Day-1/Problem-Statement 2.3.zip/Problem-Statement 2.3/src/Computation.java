
public class Computation 
{
	
	public static void main(String[] args) 
	{
		int sum = 0, avg;
		int[] A = new int[] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };
		
		for (int i = 0; i < A.length; i++) 
		{
			sum = sum + A[i];
		}
		System.out.println("Sum of all the elements of an array: " + sum);
		A[15] = sum;
		for(int val:A)
			System.out.print(val + " ");

		avg = sum / A.length;
		System.out.println("\nAverage of the " + sum + " is " + avg);
		A[16] = avg;
		for(int val:A)
			System.out.print(val + " ");
		

		int smallest = Integer.MAX_VALUE;
		int i = 0;
		while (i < A.length) {
			if (smallest > A[i]) {
				smallest = A[i];
			}
			i++;
		}
		System.out.println("\nThe smallest number in the array list is : " + smallest);
		A[17] = smallest;
		for(int val:A)
			System.out.print(val + " ");
	
	}

}
