
import java.util.ArrayList;

public class ListStudents {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();

		list.add("Tariq");
		list.add("Shreyas");
		list.add("Saneeth");
		list.add("Shashi");

		if (list.contains("Tariq"))
			System.out.println("Tariq Exists");

		else
			System.out.println("Tariq Doesn't Exists");
		
		if (list.contains("shubham"))
			System.out.println("shubham Exists");

		else
			System.out.println("shubham Doesn't Exists");

	}
}
