import java.util.Scanner;

public class ToCheckPalindrom {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		String str;
		String reverseStr = "";
		
		System.out.println("Enter a String: ");
		str = scan.next();
		
		System.out.println("Length of the String is : " + str.length());
		
		System.out.println("String in Uppercase : " + str.toUpperCase());
		
		for(int i = str.length()-1; i >= 0; i--)
		{
			reverseStr = reverseStr + str.charAt(i);
		}
		
		if(str.equals(reverseStr))
			System.out.println("Entered String is Palindrome.");
		else
			System.out.println("Entered String is not Palindrome.");
	}
}
