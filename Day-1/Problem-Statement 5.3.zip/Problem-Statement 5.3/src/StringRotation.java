
public class StringRotation {

	public static void main(String[] args) {

		String str = "MPHASIS";

		for (int i = 0; i <= str.length() - 1; i++) {
			System.out.println(leftShift(str, i));
		}
		System.out.println(str);

	}

	public static String leftShift(String s, int k) {
		String result = s;

		for (int i = 0; i < k; i++) {
			result = result.substring(1) + result.charAt(0);
		}

		return result;
	}

}