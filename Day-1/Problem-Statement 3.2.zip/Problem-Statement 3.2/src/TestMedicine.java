public class TestMedicine {

	public static void main(String[] args) {

		MedicineInfo mt = new Tablet();
		MedicineInfo ms = new Syrup();
		MedicineInfo mo = new Ointment();
		mt.displayLabel();
		ms.displayLabel();
		mo.displayLabel();
	}
}