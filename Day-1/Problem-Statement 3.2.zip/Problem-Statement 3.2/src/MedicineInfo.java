
public interface MedicineInfo {

	abstract void displayLabel();
}

class Tablet implements MedicineInfo{

	@Override
	public void displayLabel() {
		// TODO Auto-generated method stub
		System.out.println("Store in a dry place.");
	}
	
}

class Syrup implements MedicineInfo{

	@Override
	public void displayLabel() {
		// TODO Auto-generated method stub
		System.out.println("Shake well before use.");
	}
	
}

class Ointment implements MedicineInfo{

	@Override
	public void displayLabel() {
		// TODO Auto-generated method stub
		System.out.println("For external use only");
	}
	
}