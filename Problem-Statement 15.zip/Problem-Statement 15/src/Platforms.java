import java.util.*;

public class Platforms 
{
	public static void main(String[] args) 
	{
		int arrival[] = { 900, 940, 950, 1100, 1500, 1800 };
		int departure[] = { 910, 1200, 1120, 1130, 1900, 2000 };
		int length = arrival.length;
		
		System.out.println(minPlatform(arrival, departure, length));
	}

	static int minPlatform(int arr[], int dep[], int n) 
	{
		Arrays.sort(arr);
		Arrays.sort(dep);

		int plat = 1, result = 1;
		int i = 1, j = 0;

		while (i < n && j < n) 
		{
			if (arr[i] <= dep[j])
			{
				plat++;
				i++;

				if (plat > result)
					result = plat;
			}

			else
			{
				plat--;
				j++;
			}
		}

		return result;
	}

}