public class StringShuffle 
{
	public static void main(String[] args) 
	{
		String s1 = "abc";
		String s2 = "def";
		String s3 = "dabecf";
		boolean flag = false;

		StringShuffle ss = new StringShuffle();

		flag = ss.validation(s1, s2, s3);

		if (flag)
			System.out.println(flag + ": third string is valid shuffle of first and second string.");
		else
			System.out.println(flag + ": third string is NOT a valid shuffle of first and second string.");
	}

	public boolean validation(String s1, String s2, String s3)
	{
		if (s1.length() + s2.length() != s3.length()) 
		{
			return false;
		}
		return shuffle(s1, 0, s2, 0, "", s3);
	}

	public boolean shuffle(String s1, int i, String s2, int j, String result, String s3)
	{
		if (result.equals(s3) && i == s1.length() && j == s2.length())
			return true;
		boolean flag = false;
		if (i < s1.length())
			flag |= shuffle(s1, i + 1, s2, j, result + s1.charAt(i), s3);
		if (j < s2.length())
			flag |= shuffle(s1, i, s2, j + 1, result + s2.charAt(j), s3);
		return flag;

	}

}