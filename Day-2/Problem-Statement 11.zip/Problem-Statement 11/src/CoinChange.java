import java.util.Scanner;
import java.util.Vector;

public class CoinChange 
{
	
	static int change[] = { 1, 2, 5, 10, 20, 50, 100, 500, 2000 };
	static int length = change.length;

	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the currency: ");
		int input = scan.nextInt();
		
		System.out.print("BreakDown - " + input + " : ");
		findChange(input);
	}

	static void findChange(int V) 
	{
		Vector<Integer> vec = new Vector<>();

		for (int i = length - 1; i >= 0; i--)
		{
			while (V >= change[i]) 
			{
				V -= change[i];
				vec.add(change[i]);
			}
		}

		for (int i = 0; i < vec.size(); i++)
		{
			if (i == vec.size() - 1) 
			{
				System.out.println("Rs." + vec.elementAt(i));
				break;
			}
			System.out.print("Rs." + vec.elementAt(i) + " + ");
		}
	}

}