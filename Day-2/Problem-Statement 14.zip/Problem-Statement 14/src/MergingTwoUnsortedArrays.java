import java.util.*;

public class MergingTwoUnsortedArrays
{
	public static void main(String[] args) 
	{
		int first[] = { 1, 10, 5, 15 };
		int second[] = { 20, 0, 2 };
		int firstLength = first.length;
		int secondLength = second.length;

		int result[] = new int[firstLength + secondLength];
		sortedMerge(first, second, result, firstLength, secondLength);

		System.out.print("Merge list is :");
		for (int i = 0; i < firstLength + secondLength; i++)
			System.out.print(" " + result[i]);
	}

	public static void sortedMerge(int first[], int second[], int result[], int a, int b) 
	{
		int i = 0, j = 0, k = 0;
		while (i < a) 
		{
			result[k] = first[i];
			i++;
			k++;
		}

		while (j < b)
		{
			result[k] = second[j];
			j++;
			k++;
		}

		Arrays.sort(result);
	}

}
