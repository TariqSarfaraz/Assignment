import java.util.*;

public class FirstRepeatingElement 
{

	public static void main(String[] args) throws java.lang.Exception 
	{
		int a[] = { 1, 2, 3, 10, 2, 4, 5, 7, 8 };
		FirstRepeating(a);
	}

	static void FirstRepeating(int a[])
	{
		int min = -1;

		HashSet<Integer> set = new HashSet<>();

		for (int i = a.length - 1; i >= 0; i--) 
		{
			if (set.contains(a[i]))
				min = i;

			else
				set.add(a[i]);
		}

		if (min != -1)
			System.out.println("First repeating element is " + a[min]);
		else
			System.out.println("There are no repeating elements");
	}

}
