
public class ExpressionParser 
{
	public static void main(String[] args) 
	{

		String str = (" 23  +  45  -  (  343  /  12  ) ");
		String[] arr = str.split("\\s");

		for (String val : arr) {
			System.out.println(val);
		}
	}

}
