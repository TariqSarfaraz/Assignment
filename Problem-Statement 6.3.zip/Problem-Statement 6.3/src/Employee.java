
public class Employee {

	private int employeeNo;
	private String employeeName;
	private String Address;

	public Employee(int employeeNo, String employeeName, String address) {
		super();
		this.employeeNo = employeeNo;
		this.employeeName = employeeName;
		Address = address;
	}

	public int getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(int employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

}