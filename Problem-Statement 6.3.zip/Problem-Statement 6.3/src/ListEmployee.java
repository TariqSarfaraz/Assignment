
import java.util.Vector;

public class ListEmployee {
	public static void main(String[] args) {
		Vector<Employee> vector = addInput();
		display(vector);
	}

	public static Vector<Employee> addInput() {
		Employee e1 = new Employee(1, "Tariq", "Bangalore");
		Employee e2 = new Employee(2, "Shreyas", "Hyderabad");
		Employee e3 = new Employee(3, "Saneeth", "Pune");
		Vector<Employee> vector = new Vector<Employee>();
		vector.add(e1);
		vector.add(e2);
		vector.add(e3);
		return vector;

	}

	public static void display(Vector<Employee> v) {
		for (Employee e : v) {
			System.out.println(e.getEmployeeNo() + "\t" + e.getEmployeeName() + "\t\t" + e.getAddress());
		}
	}

}